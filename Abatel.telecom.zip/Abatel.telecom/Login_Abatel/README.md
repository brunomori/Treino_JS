# Formulario Login
Formulário de Login utilizando HTML + CSS

## Demonstração (Preview)


## Sobre o Projeto
Neste projeto foram utilizados alguns conceitos e ferramentas como:
- Declaração de variáveis no CSS
- Importação de fontes
- Manipulação de elementos
- Criação de formulários com campos personalizados 
- Pseudo-elementos para estilizar os campos
- Entre outros conceitos

## Descrição do desenvolvimento
Foi desenvolvido uma estrutura base de login com o HTML
Foi utilizado o CSS para realizar a estilização de todo o formulário sendo ele 100% responsivo

## Paleta de cores do desenvolvimento
#D1E3D7;
#90E8B0;
#5B635E;
#3E634C;
#A2B0A7;
Foi relizado teste de daltonismo referente a pelata das cores, as cores NÂO são compativel para o daltonismo. 

## Dipositvos compativeis 
Todos os dispositvos que tem os pixels da tela de x a y. 
Exemplos de disposivos:
-iPhone SE;
-iPhone XR;
-iPhone 12Pro;
-Pixel 5;
-Samsung Galaxy s8+;
-Samsung Galay S20 Ultra;
-Samsung Galaxy A51/71;
-iPad Mini