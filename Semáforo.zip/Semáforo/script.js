function red() {
    document.getElementById("img").src = "img/vermelho.png"
}

function yellow() {
    document.getElementById("img").src = "img/amarelo.png"
}

function green() {
    document.getElementById("img").src = "img/verde.png"
}



function stop(){
    document.getElementById("img").src="img/desligado.png"
    exit(automatic) 
}



function automatic() {


    function red() {
        document.getElementById('img').src = "img/vermelho.png"
    }
    setTimeout(red, 2500)

    function yellow() {
        document.getElementById('img').src = "img/amarelo.png"
    }
    setTimeout(yellow, 3000)

    function green() {
        document.getElementById('img').src = "img/verde.png"
    }
    setTimeout(green, 4000)
}



